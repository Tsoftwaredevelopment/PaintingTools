package mainframecommponent;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class PositionLabel extends JLabel {
	private static final long serialVersionUID = 1L;
	
	public PositionLabel() {
		super(new ImageIcon("ImageIcons/MousePostionIcon/����λ��.png"), JLabel.LEFT);
	}


}
